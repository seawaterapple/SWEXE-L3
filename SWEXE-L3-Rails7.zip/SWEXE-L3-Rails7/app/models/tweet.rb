class Tweet < ApplicationRecord
end
